package GUI;

import client.Client;
import remote.IChatController;
import remote.IClientController;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;

public class ChatScreen {

    public JPanel panel2;
    private JButton sendButton;
    private JPanel drawingPanel;
    private JPanel othersPanel;
    private JComboBox sendMessageToComboBox;
    private JTextArea chatDisplayBox;
    private JComboBox userSelectComboBox;
    private JButton kickOutButton;
    private JButton promoteToManagerButton;
    private JTextField chatInputBox;
    private JLabel sendMessageToLabel;
    private JLabel managersNameLabel;
    private JLabel yourNameLabel;
    private JLabel yourNameDisplay;
    private JLabel managersNameDisplay;
    private JPanel myAreaPanel;
    private JPanel managersPanel;
    private JPanel chatPanel;
    private JButton exitThisRoomButton;
    private JButton quitButton;
    private JFrame frame;

    private Client client;


    public ChatScreen(Client client)
    {
        this.client = client;
        yourNameDisplay.setText(client.getUserName());
//        sentMessageToComboBox.addItem(client.getUserName());
        quitButton.addActionListener(actionListener);
        sendButton.addActionListener(actionListener);
        frame = new JFrame("Application");
        frame.setContentPane(panel2);
        createUIComponents();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setResizable(false);
        frame.setVisible(true);

        SwingUtilities.getRootPane(sendButton).setDefaultButton(sendButton);
    }

    private void createUIComponents() {
        drawingPanel = new PaintGUI(client).getGlobal();
    }

    public JTextArea getChatDisplayBox() {
        return chatDisplayBox;
    }

    public JComboBox getSendMessageToComboBox()
    {
        return sendMessageToComboBox;
    }

    public JPanel getDrawingPanel() {
        return drawingPanel;
    }

    ActionListener actionListener = new ActionListener()
    {
        public void actionPerformed(ActionEvent e)
        {
            if (e.getSource() == sendButton)
            {
                String message = chatInputBox.getText();
                chatInputBox.setText("");
                IChatController chatController = client.getChatController();
                try
                {
                    System.out.println("Send button pressed");

                    String toUser = sendMessageToComboBox.getSelectedItem().toString();

                    if( toUser.equals("All") )
                    {
                        chatController.broadcastMessage(client.getUserName(), message);
                    }
                    else
                    {
                        chatController.sendPrivateMessage(client.getUserName(), toUser, message);
                    }
                }
                catch (RemoteException ex)
                {
                    ex.printStackTrace();
                }
            }
            else if (e.getSource() == exitThisRoomButton)
            {
                IClientController clientController = client.getClientController();
                try
                {
                    System.out.println("Exit room button pressed");
                    clientController.quit(client.getUserName());
                    System.exit(0);
                }
                catch (RemoteException ex)
                {
                    ex.printStackTrace();
                }
            }
        }

    };
}
