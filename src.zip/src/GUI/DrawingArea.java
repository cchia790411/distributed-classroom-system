package GUI;

import client.Client;
import remote.IDrawingController;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RectangularShape;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.rmi.RemoteException;

public class DrawingArea extends JPanel implements MouseMotionListener, MouseListener {



    /// enum for all different mode ///
    enum Mode { FREEHAND, LINE, CIRCLE, RECTANGLE, OVAL, ERASE }

    /// Canvas size parameter ///
    private final static int AREA_WIDTH = 600;
    private final static int AREA_HEIGHT = 620;

    /// Shape to be drawn on the canvas ///
    private Client client;

    private Shape drawing;

    private Point startPoint;
    private Point previousPoint;

    private Point currentPoint;
    /// Default mode and color ///
    private Color shapeColor;// = new Color(0, 0, 0);

    private Mode currentMode;// = Mode.FREEHAND;
    /// Create a empty canvas ///
    private BufferedImage image;// = new BufferedImage(AREA_WIDTH, AREA_HEIGHT, BufferedImage.TYPE_INT_ARGB);

    /// Drawing tool
    private Graphics2D g2;// = (Graphics2D) image.getGraphics();


    public DrawingArea(Client client) {
        this.client = client;
        setBackground(Color.WHITE); // Set Background color
        setDoubleBuffered(false);   // Non-buffered drawing
        image = new BufferedImage(AREA_WIDTH, AREA_HEIGHT, BufferedImage.TYPE_INT_ARGB);
        g2 = (Graphics2D) image.getGraphics();
        /// Antialiasing the graphic for smoothness ///
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        shapeColor =  new Color(0, 0, 0);
        currentMode = Mode.FREEHAND;
        drawing = null;
        addMouseListener(this);
        addMouseMotionListener(this);
    }


    public Shape getDrawing() {
        return drawing;
    }

    public void setDrawing(Shape drawing) {
        this.drawing = drawing;
    }


    @Override
    public Dimension getPreferredSize()
    {
        return isPreferredSizeSet() ?
                super.getPreferredSize() : new Dimension(AREA_WIDTH, AREA_HEIGHT);
    }

/// Create a white image to clear previous drawing ///
    public void clear() {

        image = new BufferedImage(AREA_WIDTH, AREA_HEIGHT, BufferedImage.TYPE_INT_ARGB);
        g2 = (Graphics2D) image.getGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        repaint();

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

/// Draw the whole image on JPanel ///
        if (image != null) {
                g.drawImage(image, 0, 0, null);
            }

/// Draw temporary shape ///
        if (drawing != null) {
            Graphics2D g2 = (Graphics2D) g;

/// Eraser has no border color ///
            Color borderColor = currentMode != Mode.ERASE ? shapeColor : Color.WHITE;
            g2.setColor(borderColor);
            g2.draw(drawing);
            IDrawingController drawingController = client.getDrawingController();
            try {
                drawingController.broadcastDrawing(client.getUserName(), drawing);
            } catch (RemoteException ex) {
                ex.printStackTrace();
            }
        }
    }

/// File manipulations (PNG only) ///
    public void saveFile() {
        try {
            ImageIO.write(image, "PNG", new File("Saved_White_Board.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveAsFile(File file) {
        try {
            ImageIO.write(image, "PNG", file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void openFile(File file) {
        try {
            image = ImageIO.read(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
        repaint();
    }

/// Drawing mode setters ///

    public void setModeFreehand() {
        currentMode = Mode.FREEHAND;
    }

    public void setModeLine() {
        currentMode = Mode.LINE;
    }

    public void setModeCircle() {
        currentMode = Mode.CIRCLE;
    }

    public void setModeRectangle() {
        currentMode = Mode.RECTANGLE;
    }

    public void setModeOval() {
        currentMode = Mode.OVAL;
    }

    public void setModeErase() {
        currentMode = Mode.ERASE;
    }

/// Drawing color setters ///

    public void setColorAqua() {
        shapeColor = new Color(0,255, 255);
    }

    public void setColorBlack() {
        shapeColor = new Color(0, 0, 0);
    }

    public void setColorBlue() {
        shapeColor = new Color(0, 0, 255);
    }

    public void setColorFuchsia() {
        shapeColor = new Color(255, 0, 255);
    }

    public void setColorGray() {
        shapeColor = new Color(128, 128, 128);
    }

    public void setColorGreen() {
        shapeColor = new Color(0, 128, 0);
    }

    public void setColorLime() {
        shapeColor = new Color(0, 255, 0);
    }

    public void setColorMaroon() {
        shapeColor = new Color(128,0, 0);
    }

    public void setColorNavy() {
        shapeColor = new Color(0, 0, 128);
    }

    public void setColorOlive() {
        shapeColor = new Color(128, 128, 0);
    }

    public void setColorPurple() {
        shapeColor = new Color(128, 0, 128);
    }

    public void setColorRed() {
        shapeColor = new Color(255, 0, 0);
    }

    public void setColorSilver() {
        shapeColor = new Color(192, 192, 192);
    }

    public void setColorTeal() {
        shapeColor = new Color(0, 128, 128);
    }

    public void setColorWhite() {
        shapeColor = new Color(255, 255, 255);
    }

    public void setColorYellow() {
        shapeColor = new Color(255, 255, 0);
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        startPoint = previousPoint = e.getPoint();

/// Instantiate object based on current mode ///
        switch (currentMode) {

            case FREEHAND:
            case LINE:

                drawing = new Line2D.Double();
                break;

            case ERASE:
            case CIRCLE:
            case OVAL:

                drawing = new Ellipse2D.Double();
                break;

            case RECTANGLE:

                drawing = new Rectangle2D.Double();
                break;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        switch (currentMode) {
            case OVAL:
            case RECTANGLE:
            case CIRCLE:

/// Abort drawing if 2D has no width or height ///
                if (((RectangularShape) drawing).getWidth() == 0 || ((RectangularShape) drawing).getHeight() == 0) {
                    break;
                }
            case FREEHAND:
            case LINE:
//                        Graphics2D g2 = (Graphics2D) image.getGraphics();
                g2.setColor(shapeColor);

/// Uncomment the line below to fill the shapes with color ///
//                        g2.fill(drawing);
                g2.draw(drawing);
        }

        g2 = (Graphics2D) image.getGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(shapeColor);

/// This repaint is needed if we want to fill the drawing shape with color
        repaint();

        drawing = null;
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        currentPoint = e.getPoint();

        int x = Math.min(startPoint.x, e.getX());
        int y = Math.min(startPoint.y, e.getY());
        int width = Math.abs(startPoint.x - e.getX());
        int height = Math.abs(startPoint.y - e.getY());

        switch (currentMode) {

/// Freehand drawing is continuously drawing line from current point to previous point ///
            case FREEHAND:

                ((Line2D) drawing).setLine(currentPoint, previousPoint);
                g2.setColor(shapeColor);
                g2.draw(drawing);
                previousPoint = currentPoint;
                break;

/// Single line ///
            case LINE:

                ((Line2D) drawing).setLine(startPoint, currentPoint);
                break;

/// Eraser is continuously drawing "small white circle" from current point to previous point ///
            case ERASE:

                ((Ellipse2D) drawing).setFrame(currentPoint.getX(), currentPoint.getY(), 10, 10);
                g2.setColor(Color.WHITE);
                g2.fill(drawing);
                g2.draw(drawing);
                break;

/// Single circle (How to draw more intuitively?)///
            case CIRCLE:

                double radius = Math.sqrt(width * width + height * height);
//                        ((Ellipse2D) drawing).setFrame(x, y, radius, radius);
                ((Ellipse2D) drawing).setFrame(startPoint.getX() - radius, startPoint.getY() - radius, 2 * radius, 2 * radius);
                break;

/// Single oval ///
            case OVAL:

                ((Ellipse2D) drawing).setFrame(x, y, width, height);
                break;

/// Single rectangle ///
            case RECTANGLE:

                ((Rectangle2D) drawing).setFrame(x, y, width, height);
                break;
        }

        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
}