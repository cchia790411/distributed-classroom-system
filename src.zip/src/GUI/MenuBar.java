package GUI;

import javax.swing.*;

public class MenuBar extends JMenuBar {
    JButton clearBtn, newBtn, openBtn, saveBtn, saveAsBtn, closeBtn;
}
