package GUI;

import client.Client;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class PaintGUI extends JPanel {

    Client client;
    ChatScreen chatScreen;

    String[] shapes = {"Freehand", "Line", "Circle", "Rectangle", "Oval", "Eraser"};
    String[] colors = {"Aqua", "Black", "Blue", "Fuchsia", "Gray", "Green", "Lime", "Maroon", "Navy", "Olive", "Purple", "Red", "Silver", "Teal", "White", "Yellow"};
    JFrame frame;
    JButton clearBtn, newBtn, openBtn, saveBtn, saveAsBtn, closeBtn;
    JComboBox colorOptions;
    JComboBox shapeOptions;
    DrawingArea drawingArea;


    JPanel global = new JPanel();
    JFileChooser fileChooser= new JFileChooser();
    JPanel toolbox = new JPanel();
    JPanel fileControl = new JPanel();

    /// GUI setup ///
    public PaintGUI(Client client) {

        this.client = client;

/// Main drawing area ///
        drawingArea = new DrawingArea(this.client);

/// Set up main frame and container ///
        global.setLayout(new BorderLayout());

/// Set up elements ///
        shapeOptions = new JComboBox(shapes);
        shapeOptions.addActionListener(actionListener);
        colorOptions = new JComboBox(colors);
        colorOptions.setSelectedItem("Black");
        colorOptions.addActionListener(actionListener);
        clearBtn = new JButton("Clear");
        clearBtn.addActionListener(actionListener);
        newBtn = new JButton("New");
        newBtn.addActionListener(actionListener);
        openBtn = new JButton("Open");
        openBtn.addActionListener(actionListener);
        saveBtn = new JButton("Save");
        saveBtn.addActionListener(actionListener);
        saveAsBtn = new JButton("Save As");
        saveAsBtn.addActionListener(actionListener);
        closeBtn = new JButton("Close");
        closeBtn.addActionListener(actionListener);

/// Toolbox panel ///
        toolbox.add(colorOptions);
        toolbox.add(shapeOptions);
        toolbox.add(clearBtn);

/// File control panel ///
        fileControl.add(newBtn);
        fileControl.add(openBtn);
        fileControl.add(saveBtn);
        fileControl.add(saveAsBtn);
        fileControl.add(closeBtn);

/// Layout ///
        global.add(fileControl, BorderLayout.NORTH);
        global.add(drawingArea);
        global.add(toolbox, BorderLayout.SOUTH);
    }

    public JPanel getGlobal() {
        return global;
    }

    ActionListener actionListener = new ActionListener() {

        public void actionPerformed(ActionEvent e) {

/// Clear button ///
            if (e.getSource() == clearBtn) {
                drawingArea.clear();

/// Create new canvas ///
            } else if (e.getSource() == newBtn) {
                int returnVal = JOptionPane.showConfirmDialog(new JFrame(), "Save your current whiteboard?", "Save or Discard", JOptionPane.YES_NO_CANCEL_OPTION);
                if (returnVal == JOptionPane.YES_OPTION) {

                    drawingArea.saveFile();
                    drawingArea.clear();

                } else if (returnVal == JOptionPane.NO_OPTION) {

                    drawingArea.clear();

                }

// Open file (PNG only) ///
            } else if (e.getSource() == openBtn) {
                int returnVal = fileChooser.showOpenDialog(frame);
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile();
                    drawingArea.openFile(file);
                }

/// Save under project directory without filename (PNG file with default filename) ///
            } else if (e.getSource() == saveBtn) {
                drawingArea.saveFile();

/// Save with other filename (PNG only) ///
            } else if (e.getSource() == saveAsBtn) {
                fileChooser = new JFileChooser();
                int returnVal = fileChooser.showSaveDialog(frame);
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile();
                    drawingArea.saveAsFile(file);
                }

/// Close application ///
            } else if (e.getSource() == closeBtn) {
                System.exit(0);

/// Choose drawing color ///
            } else if (e.getSource() == colorOptions) {

                String colorChosen = (String) colorOptions.getSelectedItem();

                switch (colorChosen){
                    case "Aqua":
                        drawingArea.setColorAqua();
                        break;
                    case "Black":
                        drawingArea.setColorBlack();
                        break;
                    case "Blue":
                        drawingArea.setColorBlue();
                        break;
                    case "Fuchsia":
                        drawingArea.setColorFuchsia();
                        break;
                    case "Gray":
                        drawingArea.setColorGray();
                        break;
                    case "Green":
                        drawingArea.setColorGreen();
                        break;
                    case "Lime":
                        drawingArea.setColorLime();
                        break;
                    case "Maroon":
                        drawingArea.setColorMaroon();
                        break;
                    case "Navy":
                        drawingArea.setColorNavy();
                        break;
                    case "Olive":
                        drawingArea.setColorOlive();
                        break;
                    case "Purple":
                        drawingArea.setColorPurple();
                        break;
                    case "Red":
                        drawingArea.setColorRed();
                        break;
                    case "Silver":
                        drawingArea.setColorSilver();
                        break;
                    case "Teal":
                        drawingArea.setColorTeal();
                        break;
                    case "White":
                        drawingArea.setColorWhite();
                        break;
                    case "Yellow":
                        drawingArea.setColorYellow();
                        break;
                }

/// Choose drawing tool ///
            } else if (e.getSource() == shapeOptions) {

                String shapeChosen = (String) shapeOptions.getSelectedItem();

                switch (shapeChosen){
                    case "Freehand":
                        drawingArea.setModeFreehand();
                        break;
                    case "Line":
                        drawingArea.setModeLine();
                        break;
                    case "Circle":
                        drawingArea.setModeCircle();
                        break;
                    case "Rectangle":
                        drawingArea.setModeRectangle();
                        break;
                    case "Oval":
                        drawingArea.setModeOval();
                        break;
                    case "Eraser":
                        drawingArea.setModeErase();
                        break;
                }
            }
        }
    };

    public DrawingArea getDrawingArea() {
        return drawingArea;
    }




    public void showGUI() {
        frame = new JFrame("Shared Whiteboard System");
        JFrame.setDefaultLookAndFeelDecorated(true);
        frame.setContentPane(global);

        frame.setSize(800, 600);
        frame.setLocationRelativeTo( null );
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

}