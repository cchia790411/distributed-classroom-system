package GUI;

import client.Client;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StartScreen {

    private JPanel panel1;
    private JTextArea information;
    private JTextField textField1;
    private JButton joinButton;
    private JTextField textField2;
    JFrame frame;

    private Client client;

    public StartScreen(Client client)
    {
        this.client = client;
    }

//    public static void main(String[] args) {
//        new StartScreen().go();
//    }


    ActionListener actionListener = new ActionListener()
    {
        public void actionPerformed(ActionEvent e)
        {
            if (e.getSource() == joinButton)
            {
                client.setServerAddress(textField2.getText());
                client.setUsername(textField1.getText());

                if( client.connect() )
                {
                    frame.setVisible(false);
                    frame.dispose();
                    //client.doSomething();
                    new ChatScreen(client);
                }
                else
                {
                    showErrorMessage("Could not connect to server...");
                }
            }
        }

    };

    private void showErrorMessage(String message)
    {
        JOptionPane.showMessageDialog(null,
                message, "Error", JOptionPane.PLAIN_MESSAGE);
    }

    public void go(){
        joinButton.addActionListener(actionListener);
        frame = new JFrame("StartScreen");
        frame.setContentPane(panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

}
