package GUI;

import javax.swing.*;
import java.awt.*;

public class ToolBar extends JPanel {
    private DrawingArea drawingArea;

    public ToolBar() {

    }
}

class Tools extends JPanel {

}

class ColorPallete extends JPanel {
    private Color color;

    public ColorPallete() {
        this.color = new Color(0, 0, 0);    // Black
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public void setColorRBG(int r, int b, int g) {
        this.color = new Color(r, b, g);
    }

    public Color getColor() {
        return this.color;
    }

    public void setColorAqua() {
        this.color = new Color(0,255, 255);
    }

    public void setColorBlack() {
        this.color = new Color(0, 0, 0);
    }

    public void setColorBlue() {
        this.color = new Color(0, 0, 255);
    }

    public void setColorFuchsia() {
        this.color = new Color(255, 0, 255);
    }

    public void setColorGray() {
        this.color = new Color(128, 128, 128);
    }

    public void setColorGreen() {
        this.color = new Color(0, 128, 0);
    }

    public void setColorLime() {
        this.color = new Color(0, 255, 0);
    }

    public void setColorMaroon() {
        this.color = new Color(128,0, 0);
    }

    public void setColorNavy() {
        this.color = new Color(0, 0, 128);
    }

    public void setColorOlive() {
        this.color = new Color(128, 128, 0);
    }

    public void setColorPurple() {
        this.color = new Color(128, 0, 128);
    }

    public void setColorRed() {
        this.color = new Color(255, 0, 0);
    }

    public void setColorSilver() {
        this.color = new Color(192, 192, 192);
    }

    public void setColorTeal() {
        this.color = new Color(0, 128, 128);
    }

    public void setColorWhite() {
        this.color = new Color(255, 255, 255);
    }

    public void setColorYellow() {
        this.color = new Color(255, 255, 0);
    }
}