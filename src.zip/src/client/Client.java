package client;

import GUI.ChatScreen;
import GUI.PaintGUI;
import GUI.StartScreen;
import remote.IChatController;
import remote.IClientController;
import remote.IDrawingController;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client
{
    private String userName;
    private String serverAddress;

    private Registry registryServer;
    private IChatController chatController;
    private IClientController clientController;

    private IDrawingController drawingController;

    private ClientUpdate clientUpdate;

    private ChatUpdate chatUpdate;
    private DrawingUpdate drawingUpdate;
    private StartScreen startScreen;

    private ChatScreen chatScreen;
    private PaintGUI paintGUI;

    private String receivedMessage;

    private String[] connectedUsers;


    public PaintGUI getPaintGUI() {
        return paintGUI;
    }


    public ChatScreen getChatScreen()
    {
        return chatScreen;
    }

    public void setConnectedUsers(String[] users)
    {
        this.connectedUsers = users;
    }


    public IChatController getChatController()
    {
        return chatController;
    }

    public IClientController getClientController()
    {
        return clientController;
    }

    public IDrawingController getDrawingController() { return drawingController; }

    public void setUsername(String userName)
    {
        this.userName = userName;
    }

    public String getUserName()
    {
        return this.userName;
    }

    public void setServerAddress(String serverAddress)
    {
        this.serverAddress = serverAddress;
    }

    public Client(String username) throws RemoteException
    {
        this.userName = username;
        this.clientUpdate = new ClientUpdate(this);
        this.chatUpdate = new ChatUpdate(this);
        this.drawingUpdate = new DrawingUpdate(this);
        this.startScreen = new StartScreen(this);
        this.chatScreen = new ChatScreen(this);
        this.paintGUI = new PaintGUI(this);
    }

    public static void main(String[] args)
    {
        try
        {
            Client client = new Client(args[0]);
            client.connect();
//            client.startScreen.go();
//            client.getPaintGUI().showGUI();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

//    public void doSomething()
//    {
////        new ChatScreen();
//
//        try
//        {
//            new ChatScreen(this);
//            System.out.println("Sleeping...");
//            TimeUnit.MINUTES.sleep(5);
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//        }
//    }

    public boolean connect()
    {
        try
        {
            registryServer = LocateRegistry.getRegistry(serverAddress);

            chatController = (IChatController) registryServer.lookup("ChatController");
            clientController = (IClientController) registryServer.lookup("ClientController");
            drawingController = (IDrawingController) registryServer.lookup("DrawingController");

            if (clientController.join(userName, this.chatUpdate, this.clientUpdate, this.drawingUpdate))
            {
                System.out.println("Connected to server");

                return true;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return false;
    }

    public String getReceivedMessage()
    {
        return receivedMessage;
    }

    public void setReceivedMessage(String receivedMessage)
    {
        this.receivedMessage = receivedMessage;
    }
}