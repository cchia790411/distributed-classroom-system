package client;

import remote.IClientUpdate;

import javax.swing.*;
import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ClientUpdate extends UnicastRemoteObject implements IClientUpdate, Serializable {

    private Client client;

    public ClientUpdate(Client client) throws RemoteException
    {
        super();
        this.client = client;
    }

    @Override
    public boolean notifyClient(String fromClient, String newUsername) throws RemoteException
    {
        client.getChatScreen().getSendMessageToComboBox().addItem(newUsername);

        return true;
    }

    @Override
    public boolean updateUserList(String[] users) throws RemoteException
    {
        //client.setConnectedUsers(users);

        JComboBox userBox = client.getChatScreen().getSendMessageToComboBox();

        userBox.removeAllItems();

        userBox.addItem("All");

        for( String s : users )
        {
            if( !s.equals(client.getUserName()) )
            {
                userBox.addItem(s);
            }
        }

        return true;
    }
}
