package client;

import GUI.DrawingArea;
import remote.IDrawingUpdate;

import java.awt.*;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class DrawingUpdate extends UnicastRemoteObject implements IDrawingUpdate, Serializable {

    private Client client;

    public DrawingUpdate(Client client) throws RemoteException {
        super();
        this.client = client;
    }

    @Override
    public boolean notifyDrawing(String fromClient, Shape drawing) throws RemoteException {
        client.getPaintGUI().getDrawingArea().setDrawing(drawing);
        client.getPaintGUI().getDrawingArea().repaint();
        DrawingArea drawingArea = (DrawingArea) client.getChatScreen().getDrawingPanel().getComponent(1);
        drawingArea.setDrawing(drawing);
        drawingArea.repaint();
        return false;
    }
}
