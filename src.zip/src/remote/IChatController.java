package remote;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IChatController extends Remote
{
    boolean broadcastMessage(String fromClient, String message) throws RemoteException;
    boolean broadcastMessageUserLogin(String fromClient) throws RemoteException;
    boolean broadcastMessageUserLogout(String fromClient) throws RemoteException;
    boolean sendPrivateMessage(String fromClient, String toClient, String message) throws RemoteException;
}
