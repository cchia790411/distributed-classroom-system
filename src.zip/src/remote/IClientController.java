package remote;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IClientController extends Remote
{
    boolean join(String username, IChatUpdate clientChat, IClientUpdate clientUpdate, IDrawingUpdate clientDrawing) throws RemoteException;

    void quit(String username) throws RemoteException;

    boolean assignAdmin(String username) throws RemoteException;

    boolean kickUser(String username, String who) throws RemoteException;
}
