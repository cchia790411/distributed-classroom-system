package remote;

import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IClientUpdate extends Remote, Serializable {

    boolean notifyClient(String fromClient, String newUsername) throws RemoteException;

    boolean updateUserList(String[] users) throws RemoteException;
}
