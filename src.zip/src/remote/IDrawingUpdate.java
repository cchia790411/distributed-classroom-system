package remote;

import java.awt.*;
import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IDrawingUpdate extends Remote, Serializable {
    boolean notifyDrawing(String fromClient, Shape drawing) throws RemoteException;
}
