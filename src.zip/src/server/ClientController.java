package server;

import remote.IChatUpdate;
import remote.IClientController;
import remote.IClientUpdate;
import remote.IDrawingUpdate;

import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ClientController extends UnicastRemoteObject implements IClientController, Serializable
{
    private Server server;

    protected ClientController(Server server) throws RemoteException
    {
        this.server = server;
    }

    @Override
    public boolean join(String username, IChatUpdate clientChat, IClientUpdate clientUpdate, IDrawingUpdate clientDrawing) throws RemoteException
    {
        server.chatController.broadcastMessageUserLogin(username);

        User newUser = new User(username, clientChat, clientUpdate, clientDrawing);

        server.users.add(newUser);

        if(server.users.size() == 1)
        {
            server.users.get(0).setAdmin(true);
        }

        System.out.println(username + " registered successfully");

        broadcastUserList();

        return true;
    }

    @Override
    public void quit(String username) throws RemoteException
    {
        int userIndex = getUserIndex(username);

        if( userIndex >= 0 )
        {
            server.users.remove(userIndex);

            server.chatController.broadcastMessageUserLogout(username);

            broadcastUserList();
        }
    }

    @Override
    public boolean assignAdmin(String username) throws RemoteException
    {
        int adminIndex = getUserIndex(username);

        if( adminIndex >= 0 )
        {
            server.users.get(adminIndex).setAdmin(true);

            return true;
        }

        return false;
    }

    @Override
    public boolean kickUser(String username, String who) throws RemoteException
    {
        int userIndex = getUserIndex(who);

        int adminIndex = getUserIndex(username);

        if ( adminIndex > 0 && userIndex > 0 && server.users.get(adminIndex).isAdmin() )
        {
            server.users.remove(userIndex);

            broadcastUserList();

            return true;
        }

        return false;
    }

    public int getUserIndex(String username)
    {
        int index = -1;

        for( int i = 0; i < server.users.size(); i++ )
        {
            if( server.users.get(i).getUserName().equals(username) )
            {
                index = i;
                break;
            }
        }

        return index;
    }

    private void broadcastUserList() throws RemoteException
    {
        String[] connectedUsers = new String[server.users.size()];

        for( int i = 0; i<server.users.size(); i++ )
        {
            connectedUsers[i] = server.users.get(i).getUserName();
        }

        for( User u : server.users )
        {
            u.getIClientUpdate().updateUserList(connectedUsers);
        }
    }
}
