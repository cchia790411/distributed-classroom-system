package server;

import remote.IDrawingController;
import remote.IDrawingUpdate;

import java.awt.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class DrawingController extends UnicastRemoteObject implements IDrawingController {

    private Server server;

    protected DrawingController(Server server) throws RemoteException {
        this.server = server;
    }

    @Override
    public boolean broadcastDrawing(String fromClient, Shape drawing) throws RemoteException {
        System.out.print("Broadcasting drawing to everyone...");

        IDrawingUpdate client;

        for( User u : server.users )
        {
            client = u.getIDrawingUpdate();
            client.notifyDrawing(fromClient, drawing);
        }

        System.out.print("...DONE\n");

        return true;
    }
}