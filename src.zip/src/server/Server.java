package server;

import remote.IChatController;
import remote.IClientController;
import remote.IDrawingController;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;

public class Server
{
    protected ArrayList<User> users;

    protected ClientController clientController;
    protected ChatController chatController;
    protected DrawingController drawingController;

    public Server() throws RemoteException
    {
        users = new ArrayList<User>();
        clientController = new ClientController(this);
        chatController = new ChatController(this);
        drawingController = new DrawingController(this);
    }

    public static void main(String[] args)
    {
        try
        {
            Server server = new Server();

            server.run();
        }
        catch( Exception e )
        {
            e.printStackTrace();
        }
    }

    public void run() throws RemoteException
    {

        LocateRegistry.createRegistry(1099);
        Registry registry = LocateRegistry.getRegistry();

        String clientControllerName = "ClientController";
        String chatControllerName = "ChatController";
        String drawingControllerName = "DrawingController";

        IClientController clientController = new ClientController(this);
        IChatController chatController = new ChatController(this);
        IDrawingController drawingController = new DrawingController(this);

        registry.rebind(clientControllerName, clientController);
        registry.rebind(chatControllerName, chatController);
        registry.rebind(drawingControllerName, drawingController);

        System.out.println("Server is ready");
    }
}
