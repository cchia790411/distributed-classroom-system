package server;

import remote.IChatUpdate;
import remote.IClientUpdate;
import remote.IDrawingUpdate;

public class User
{
    private String username;
    private IChatUpdate IChatUpdate;
    private IDrawingUpdate IDrawingUpdate;
    private IClientUpdate IClientUpdate;
    private boolean isAdmin;

    public User(String username, IChatUpdate IChatUpdate, IClientUpdate IClientUpdate, IDrawingUpdate IDrawingUpdate)
    {
        this.username = username;
        this.IChatUpdate = IChatUpdate;
        this.IDrawingUpdate = IDrawingUpdate;
        this.IClientUpdate = IClientUpdate;
        this.isAdmin = false;
    }

    public String getUserName()
    {
        return this.username;
    }

    public void setAdmin(boolean admin)
    {
        isAdmin = admin;
    }

    public boolean isAdmin()
    {
        return isAdmin;
    }

    public IChatUpdate getIChatUpdate()
    {
        return this.IChatUpdate;
    }

    public IDrawingUpdate getIDrawingUpdate() { return this.IDrawingUpdate; }

    public IClientUpdate getIClientUpdate() { return this.IClientUpdate; }
}
